<?php
include_once '../Repositories/UsersRepository.php';

class UsersService{
private $userRepo;

private   $RESPONSE="";



function __construct( ) {
   $this->userRepo=new UsersRepository();
}


// RETURN AN USER
public function getUser($userId){
   $user=  $this->userRepo->getUser($userId);
    return $user;
}


// fetch user of provided email and password exists in database
public function getUserByEmailPassword($email,$pass){
   $user=  $this->userRepo->getUserByEmailPassword($email,$pass);
    return $user;
}


// RETURN ALL USERS
function getAllUsers(){
  
}

// ADD NEW USER
function addUser(){

}

// DELETE EXISTING USER
function deleteUser(){

}


// UPDATE USER
function updateUser(){

}

}
?>