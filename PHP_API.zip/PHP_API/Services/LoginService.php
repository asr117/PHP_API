<?php
error_reporting(0);
include_once '../Services/UsersService.php';
session_start();


class LoginService{
    private $usersService;
    function __construct(){
       $this->usersService=new UsersService();
    }
    
    
    public function matchLoginData($loginData){
        $response="";
       $originaladata= $this->usersService->getUserByEmailPassword($loginData["email"],$loginData["password"]);
       if(sizeof($originaladata)==1){
          if($originaladata[0]["email"]==$loginData["email"]&&
           $originaladata[0]["password"]==$loginData["password"]){
               
               $_SESSION["userId"]=$originaladata[0]["id"];
               $response=array(
                   "userid"=> $originaladata[0]["id"],
                   "email"=>$loginData["email"]
                   );
           }           
           
           return $response;
       }
       
       
    }
    
    
    
}