<?php
class DBConnection{
private $username="id2802279_asr";      // mysqli database username
private $password="facebook";         // mysqli database password
private $host="localhost";          
private $db="id2802279_asr";        // database name of mysql

public function getConnection(){
    $conn= new mysqli($this->host,$this->username,$this->password,$this->db);       //CREATE NEW $CONN CONNECTION OBJECT

    if($conn->connect_error){   // TO CHECK WEATHER ANY ERROR OCCURED IN $CONN CONNECTION OBJECT 
        echo " errr";
        }
    else
    {
        // echo "connected";
    }

    return $conn;
}

}

?>