<?php
header("Content-Type: application/json; charset=UTF-8");

class ControllerHelpers{
    
public function decodeJSON(){
    // GET CLIENT JSON CONTENTS AND DECODE JSON
  return  json_decode(file_get_contents('php://input'), true);
}


public function queryParams(){
//  PARSE URL 
    $url_components = parse_url($_SERVER['REQUEST_URI']);      
// PARSE QUERY PARAMS 
    parse_str($url_components['query'], $params); 
    return   $params; 
    }
}

?>