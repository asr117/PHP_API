<?php
include_once '../Configurations/connection.php';
class UsersRepository{
private $conn;

function __construct( ) {
    $dbObj=   new DBconnection();
   $this->conn=  $dbObj->getConnection();

 
}





public function getUser($userId){
    $get_users_sql="SELECT * FROM instausers where id=$userId";
    $data=$this->conn->query($get_users_sql);
    $users=$data->fetch_all(MYSQLI_ASSOC);
    return $users;
}

public function getUserByEmailPassword($email,$pass){
     $get_users_sql="SELECT * FROM instausers where email='$email' AND password='$pass'";
    $data=$this->conn->query($get_users_sql);
    $users=$data->fetch_all(MYSQLI_ASSOC);
    return $users;
    
}


}

?>