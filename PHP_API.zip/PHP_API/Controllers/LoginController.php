<?php

// error_reporting(0);

include_once '../Helpers/ControllerHelpers.php';
include_once '../Services/LoginService.php';
session_start();

$loginController=new LoginController();
$loginController->HandleHTTPRequest($_SERVER["REQUEST_METHOD"]);


class LoginController{
        private $loginService;
    private $C_Helper;
    function __construct(){
       $this->loginService=new LoginService();
        $this->C_Helper=new ControllerHelpers(); 
    }
    
    
    
    
    
    public function HandleHTTPRequest($ReqMethod){
        
        
        if($ReqMethod=="POST"){
              $_POST=$this->C_Helper->decodeJSON();
         echo     $_POST["email"];
              $_POST["password"];
              
          $response=    $this->loginService->matchLoginData($_POST);
        
        echo sizeof($response);
      echo $response[0]["name"] ;
   echo json_encode($response);
        }
    }
    
    
    
}

?>