<?php
// error_reporting(0);
include_once '../Helpers/ControllerHelpers.php';
include_once '../Services/UsersService.php';
session_start();

$usersController=new UsersController();
$usersController->HandleHTTPRequest($_SERVER["REQUEST_METHOD"]);

class UsersController{
    private $usersService;
    private $C_Helper;
    function __construct(){
       $this->usersService=new UsersService();
        $this->C_Helper=new ControllerHelpers(); 
    }
    
// function for handling http requests
public function HandleHTTPRequest($RequestMethod){
    
    
// HANDLE GET REQUESTS
if($RequestMethod=="GET"){
  $params=$this->C_Helper->QueryParams(); //Extract Query Parameters
  $Response= $this->usersService->getUser($params['id']);
  echo  json_encode($Response);         //set array to json
}




// HANDLES POST REQUESTS
if($RequestMethod=="POST"){
    $_POST = $this->C_Helper->decodeJSON();
    echo $_POST['id'];
}




// HANDLE PUT REQUSET
if($RequestMethod=="PUT"){
    echo "PUT";
}



// HANDLE DELETE REQUSET
if($RequestMethod=="DELETE"){
    echo "Delete";
    }
  }
}


?>